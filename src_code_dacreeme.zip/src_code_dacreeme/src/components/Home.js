import React from "react";
import Content from "./Content";

class Home extends React.Component {
  render() {
    return <Content />;
  }
}

export default Home;
